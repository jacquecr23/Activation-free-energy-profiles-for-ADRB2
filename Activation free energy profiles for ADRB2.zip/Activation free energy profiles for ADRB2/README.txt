For the binary ADRB2-adrenaline complex, starting structure (adr_bin_conf.gro) and topology files for the MD run are provided.
32 representative structures were extracted from the MD trajectory to initialise each walker. The protein-ligand coordinates are provided as pdb files.
Plumed input file to run MW-MetaD with A100 CV is also provided (plumed.dat).
Plumed input files to reweight the A100 metadynamics simulation along the microswitches are also provided (plumed_reweight_microsw_adr_bin.dat, plumed_reweight_2D_microsw_adr_bin.dat, COLVAR (for only 15ns of the trajectory)).